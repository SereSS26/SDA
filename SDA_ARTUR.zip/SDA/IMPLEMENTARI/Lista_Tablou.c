#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
    return 0;
}