void starton(void); 
float startoff(void); 