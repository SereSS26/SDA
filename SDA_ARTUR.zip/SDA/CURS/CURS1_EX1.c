#include <stdio.h>
#include <stdlib.h>

int putere(int baza,int exponent)
{
    int rezultat=1,i=0;
    for(i=0;i<exponent;i++)
    {
        rezultat=rezultat*baza;
    }
    return rezultat;
}

int main(void)
{   
    int baza=0,exponent=0,rezultat=0;
    printf("Baza este: ");
    scanf("%d",&baza);
    printf("Exponentul este: ");
    scanf("%d",&exponent);
    rezultat=putere(baza,exponent);
    printf("Rezultatul este: %d\n",rezultat);

    return 0;
}